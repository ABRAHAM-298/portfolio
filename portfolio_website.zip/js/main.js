
console.log("Setting document title");
document.title = "Hunsuwhegbe Abraham - Portfolio";

const body = document.body;

const memoizedElements = new Map();

function createElement(type, options = {}, children = []) {
  const key = JSON.stringify({ type, options });
  if (memoizedElements.has(key)) {
    console.log(`Reusing memoized element: ${type}`);
    return memoizedElements.get(key).cloneNode(true);
  }

  console.log(`Creating element: ${type}`);
  const el = document.createElement(type);
  Object.entries(options).forEach(([key, value]) => {
    if (key === 'text') el.textContent = value;
    else if (key === 'class') el.className = value;
    else if (key === 'attrs' && typeof value === 'object') {
      Object.entries(value).forEach(([attr, val]) => el.setAttribute(attr, val));
    } else if (key in el) {
      el[key] = value;
    }
  });
  children.forEach(child => el.appendChild(child));
  memoizedElements.set(key, el.cloneNode(true));
  console.log(`Finished creating element: ${type}`);
  return el;
}

const header = createElement("header", { attrs: { role: "banner" } }, [
  createElement("img", { attrs: { src: "images/logo.png", alt: "Wanu Webtech Design Co.", class: "logo", width: "150", height: "150" } }),
  createElement("h1", { text: "Hunsuwhegbe Abraham" }),
  createElement("p", { text: "C.E.O — Wanu Webtech Design Co." })
]);
body.appendChild(header);

const hero = createElement("section", { class: "hero", attrs: { role: "region", 'aria-label': "Hero" } }, [
  createElement("img", { attrs: { src: "images/profile.jpg", alt: "Hunsuwhegbe Abraham", class: "profile", width: "200", height: "200" } }),
  createElement("h2", { text: "Crafting modern web experiences" })
]);
body.appendChild(hero);

const aboutParas = [
  "My name is Hunsuwhegbe Abraham, and I am the creative force behind Wanu Webtech Design Co., where every pixel tells a story and every line of code whispers possibility. I weave together graphics, flyers, and videos into digital experiences that speak louder than words.",
  "I am driven by a relentless passion to craft and create, to push boundaries and explore the limitless canvas of the web. Each project is not just a task but a journey where creativity meets purpose.",
  "Every design is born from a spark of inspiration that refuses to fade, compelling me to keep learning, building, and imagining what comes next. The story of my work is never finished, and as long as there is another idea, vision, or dream to bring to life, I will keep moving forward — turning thoughts into reality, and reality into something even greater."
];

const about = createElement("section", { class: "section about", attrs: { role: "region", 'aria-label': "About Me" } }, [
  createElement("h2", { text: "About Me" }),
  ...aboutParas.map(text => createElement("p", { text }))
]);
body.appendChild(about);

const projects = createElement("section", { class: "section projects", attrs: { role: "region", 'aria-label': "Projects" } }, [
  createElement("h2", { text: "Projects" }),
  createElement("ul", {}, [
    ...["Graphics Designing", "Flyer Design", "Video Editing"].map(item =>
      createElement("li", {}, [
        createElement("strong", { text: item })
      ])
    )
  ])
]);
body.appendChild(projects);

const contact = createElement("section", { class: "contact", attrs: { role: "contentinfo" } }, [
  createElement("h2", { text: "Contact" }),
  createElement("p", { text: "📞 +2349027314980" }),
  createElement("p", { text: "📧 wanuwebtechdesign.co" })
]);
body.appendChild(contact);

console.log("Portfolio page generation complete");
